#ifndef __FRACTALE__
#define __FRACTALE__

#include "ez-draw.h"
#include "ez-image.h"

#include "Fractale.h"
#include <stdio.h>
#include "listep.h"
#include "listep_op.h"
#include "draw.h"
#define LARGEUR 1000
#define HAUTEUR 800


typedef struct {

	PLISTE liste;
	Ez_image *onglet1;

}Data;

void win1_event (Ez_event *ev);
void win1_on_Expose(Ez_event *ev);
void win1_on_KeyPress(Ez_event *ev);
void image_data_init (Data *a, char *filename);

#endif 
