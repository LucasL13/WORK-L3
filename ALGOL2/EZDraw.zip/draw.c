#include "draw.h"
#include <stdio.h>

void draw_polygon(Ez_window win, PLISTE list){

	EPOINT point1, point2, premierpoint;
	int i=0;

	if(list != NULL && list -> next != NULL){
		premierpoint.x = list -> x;
		premierpoint.y = list -> y;
		
		point1.x = list -> x;
		point1.y = list -> y;

		//point2.x = list -> x;
		//point2.x = list -> y;
	
		list = list -> next;
	
		while(list != NULL){ 
	
			
		
			point2.x = list -> x;
			point2.y = list -> y;
		
			ez_draw_line(win, point1.x, point1.y, point2.x, point2.y);
			//printf("j'dessine entre x = %.2lf y = %.2lf et x = %.2lf y = %.2lf \n",point1.x,point1.y,point2.x,point2.y);
			point1.x = point2.x;
			point1.y = point2.y;
			
			
			list = list -> next;
		}
	
		ez_draw_line(win, point2.x, point2.y, premierpoint.x, premierpoint.y);
	
	}

}

void draw_frac_carre(Ez_window win, PLISTE list, int taille, int posx, int poxy){

	



}

void genere_carre(double taille, double posx, double posy){

	FILE* f1 = fopen("carre.out","w");	
	fprintf(f1,"%.2lf %.2lf\n",posx,posy);
	fprintf(f1,"%.2lf %.2lf\n",posx+taille,posy);
	fprintf(f1,"%.2lf %.2lf\n",posx+taille,posy+taille);
	fprintf(f1,"%.2lf %.2lf\n",posx,posy+taille);
	fclose(f1);
	
}











