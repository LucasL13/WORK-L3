#include "Fractale.h"


int main ()
{ 
    if (ez_init() < 0) exit(1); 
    
    Data *data = malloc(sizeof(Data));
    
     
    genere_carre(100,50,50);
    PLISTE liste = lire_liste("k/k2.in");  
    image_data_init(data,"images/onglet_carre.png");
    
    data -> liste = liste; 

    Ez_window win = ez_window_create (LARGEUR, HAUTEUR, "Fractale", win1_event); 
    
    ez_set_data(win,data);
    
    ez_window_dbuf(win, 1); // double buff pour les images
    
    ez_start_timer (win, 1); // début du timer (pour rentre au moins une fois dans TimerNotify)
    
    ez_main_loop(); 
    exit(0);
}
 
void image_data_init (Data *a, char *filename)
{
    a->onglet1 = ez_image_load (filename);                   /* Load an image */
    if (a->onglet1 == NULL) exit (1);
}

void win1_on_timer_notify (Ez_event *ev)            /* The timer has expired */
{
    
    
    ez_send_expose (ev->win);
    
    ez_start_timer (ev->win, 5); // on execute ce qu'il y a dans case Expose tout les 5 ms
}

void win1_on_Expose(Ez_event *ev){
	
	Data *d = ez_get_data(ev->win);
	ez_set_color(ez_blue);
        ez_set_thick(2);    
        ez_image_paint(ev->win, d->onglet1, 0,HAUTEUR-200); //onglet "carre"
        draw_polygon(ev->win,d -> liste);
        
        //ez_fill_rectangle(ev->win,0,0,LARGEUR / 100 * 20,HAUTEUR); // barre de gauche

}

void win1_on_KeyPress(Ez_event *ev){

	switch(ev->key_sym){
	
		case XK_q : ez_quit();
	 
	
	}
}

void win1_event (Ez_event *ev)                   /* Called by ez_main_loop() */
{   
	
		
		                                          /* for each event on win1   */
    switch (ev->type) {

	case TimerNotify:
		win1_on_timer_notify(ev);
		break;
		
	case Expose:
		win1_on_Expose(ev);
		break;

        case KeyPress :                                 /* A key was pressed */
            
            win1_on_KeyPress(ev);
            
            break;
    }
}
