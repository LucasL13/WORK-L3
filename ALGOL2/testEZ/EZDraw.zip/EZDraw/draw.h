#ifndef __DRAWOP__
#define __DRAWOP__

#include "ez-draw.h"
#include <stdio.h>
#include "listep.h"
#include "listep_op.h"

void draw_polygon(Ez_window win, PLISTE list);
void draw_frac_carre(Ez_window win, PLISTE list, int taille, int posx, int poxy);
void genere_carre(double taille, double posx, double posy);

#endif 
