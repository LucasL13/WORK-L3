void win1_event (Ez_event *ev);
void win1_on_Expose(Ez_event *ev);
void win1_on_KeyPress(Ez_event *ev);
